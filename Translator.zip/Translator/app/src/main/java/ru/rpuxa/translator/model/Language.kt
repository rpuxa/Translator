package ru.rpuxa.translator.model

import java.io.Serializable

data class Language(val code: Int, val name: String) : Serializable {

    companion object {
        @JvmField
        val NULL = Language(-1488, "...")
        val RUSSIAN = Language(-1488, "RUSSIAN")
        val ENGLISH = Language(-1488, "ENGLISH")
    }
}