package ru.rpuxa.translator.view

import android.animation.ValueAnimator
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.constraint.ConstraintSet
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils.loadAnimation
import kotlinx.android.synthetic.main.languages.*
import kotlinx.android.synthetic.main.languages.view.*
import ru.rpuxa.translator.R
import ru.rpuxa.translator.observeNotNull
import ru.rpuxa.translator.presenter.Presenter

class LanguagesFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
            inflater.inflate(R.layout.languages, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view as ConstraintLayout

        view.swap_languages.setOnClickListener {
            startAnimation()
        }

        Presenter.fromLanguage.observeNotNull(this) {
            from_language_textview.text = it.name
        }

        Presenter.toLanguage.observeNotNull(this) {
            to_language_textview.text = it.name
        }
    }


    private val swapAnimator by lazy {
        ValueAnimator.ofFloat(0f, 1f, 0f).apply {
            duration = resources.getInteger(R.integer.language_swap_animation_duration).toLong()
        }
    }
    private val rotateAnimation: Animation by lazy {
        loadAnimation(context, R.anim.rotate_center)
    }

    private fun startAnimation() {
        val constraint = view as ConstraintLayout
        val set = ConstraintSet()
        set.clone(constraint)
        swapAnimator.cancel()
        rotateAnimation.cancel()

        var swapped = false
        swapAnimator.addUpdateListener {
            val fromLanguageValue = it.animatedValue as Float
            val toLanguageValue = 1 - fromLanguageValue
            set.setHorizontalBias(R.id.from_language_textview, fromLanguageValue)
            set.setHorizontalBias(R.id.to_language_textview, toLanguageValue)

            if (!swapped && it.animatedFraction > .5f) {
                Presenter.swapLanguages()
                swapped = true
            }
            set.applyTo(constraint)
        }

        swap_languages.startAnimation(rotateAnimation)
        swapAnimator.start()
    }
}