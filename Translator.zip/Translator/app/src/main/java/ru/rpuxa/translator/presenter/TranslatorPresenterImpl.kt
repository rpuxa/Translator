package ru.rpuxa.translator.presenter

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import ru.rpuxa.translator.model.Language
import ru.rpuxa.translator.model.TranslateItem
import ru.rpuxa.translator.model.TranslatorModel

class TranslatorPresenterImpl(val model: TranslatorModel) : TranslatorPresenter {

//    var translateView: TranslateView? = null
//    var languagesListView: LanguagesListView? = null

    override val fromLanguage = MutableLiveData<Language>().apply { value = Language.RUSSIAN }

    override val toLanguage = MutableLiveData<Language>().apply { value = Language.ENGLISH }

    override val translatesHistory: LiveData<List<Language>> =
            MutableLiveData()

    override val allLanguages: Array<Language>
        get() = arrayOf(Language.ENGLISH, Language.RUSSIAN)

            override fun swapLanguages() {
        val tmp = fromLanguage.value
        fromLanguage.value = toLanguage.value
        toLanguage.value = tmp
    }

    override fun onTranslate(translate: TranslateItem) {

    }

   /* private inline fun <T : LifecycleOwner> T?.executeIfActive(lambda: T.() -> Unit) {
        if (this != null && lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED))
            lambda()
    }*/
}