package ru.rpuxa.translator.model

class TranslateItem()