package ru.rpuxa.translator.view

import android.app.Activity
import android.support.v7.recyclerview.extensions.ListAdapter
import android.support.v7.util.DiffUtil
import android.support.v7.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import kotlinx.android.synthetic.main.language_item.view.*
import ru.rpuxa.translator.R
import ru.rpuxa.translator.model.Language

class LanguagesAdapter(val activity: Activity) : ListAdapter<Language, LanguagesAdapter.LanguageViewHolder>(DIFF) {
    class LanguageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val text: TextView = view.language_name
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LanguageViewHolder {
        val view = View.inflate(parent.context, R.layout.language_item, parent)

        return LanguageViewHolder(view)
    }

    override fun onBindViewHolder(holder: LanguageViewHolder, position: Int) {
        val language = getItem(position)
        holder.text.text = language.name

        holder.itemView.setOnClickListener {

        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Language>() {
            override fun areItemsTheSame(oldItem: Language?, newItem: Language?): Boolean =
                    oldItem == newItem

            override fun areContentsTheSame(oldItem: Language?, newItem: Language?): Boolean =
                    oldItem == newItem
        }
    }
}