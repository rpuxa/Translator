package ru.rpuxa.translator.view

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.DividerItemDecoration
import android.support.v7.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_languages_list.*
import ru.rpuxa.translator.R
import ru.rpuxa.translator.presenter.Presenter

class LanguagesListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.languages)
        val adapter = LanguagesAdapter()
        adapter.submitList(Presenter.allLanguages)
        val manager = LinearLayoutManager(this)
        languages_recyclerview.addItemDecoration(DividerItemDecoration(this, manager.orientation))
        languages_recyclerview.adapter = adapter
        languages_recyclerview.layoutManager = manager
    }
}