package ru.rpuxa.translator.presenter

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import ru.rpuxa.translator.model.Language
import ru.rpuxa.translator.model.TranslateItem

interface TranslatorPresenter {

    val fromLanguage: MutableLiveData<Language>

    val toLanguage: MutableLiveData<Language>

    val translatesHistory: LiveData<List<Language>>

    val allLanguages: List<Language>

    fun swapLanguages()

    fun onTranslate(translate: TranslateItem)
}