package ru.rpuxa.translator.presenter

import ru.rpuxa.translator.model.TranslateModelImpl

object Presenter : TranslatorPresenter by TranslatorPresenterImpl(TranslateModelImpl())