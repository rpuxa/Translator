package ru.rpuxa.translator.model

class TranslateModelImpl : TranslatorModel {
}