package ru.rpuxa.translator.model

interface TranslatorModel {
}